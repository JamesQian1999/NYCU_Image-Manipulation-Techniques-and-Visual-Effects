1. Trained on the MNIST dataset 
    python DDPM_minist.py

2. Trained on the Anime Face dataset
    python DDPM_anime.py
